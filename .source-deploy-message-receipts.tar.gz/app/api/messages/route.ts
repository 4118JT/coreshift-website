import { database, ensureDatabase } from "../../../db/runtime";
import { getViewer } from "../../../db/viewer";

async function access() {
  const viewer = await getViewer();
  if (viewer.access === "pending") return { viewer, enabled: false };
  await ensureDatabase();
  let setting: { value: string } | null = null;
  try {
    setting = await database().prepare("SELECT value FROM workspace_settings WHERE key = ?").bind(`messaging_enabled:${viewer.businessId}`).first<{ value: string }>();
  } catch {
    await ensureDatabase();
    setting = await database().prepare("SELECT value FROM workspace_settings WHERE key = ?").bind(`messaging_enabled:${viewer.businessId}`).first<{ value: string }>();
  }
  return { viewer, enabled: setting?.value !== "false" };
}

export async function GET(request: Request) {
  const { viewer, enabled } = await access();
  if (viewer.access === "pending") return Response.json({ error: "Not authorized" }, { status: 403 });
  if (!enabled) return Response.json({ enabled: false, messages: [] });
  const conversationId = new URL(request.url).searchParams.get("conversationId") || "managers";
  const viewerType = viewer.access === "employee" ? "employee" : "owner";
  const viewerId = viewer.access === "employee" ? viewer.employeeId ?? 0 : 0;
  const [rows, reactionRows, readRows] = await Promise.all([
    database().prepare(`SELECT id, sender_type AS senderType, sender_id AS senderId, sender_name AS senderName, body, created_at AS createdAt FROM (SELECT id, sender_type, sender_id, sender_name, body, created_at FROM messages WHERE business_id = ? AND conversation_id = ? ORDER BY created_at DESC, id DESC LIMIT 100) recent ORDER BY created_at ASC, id ASC`).bind(viewer.businessId, conversationId).all(),
    database().prepare(`SELECT mr.message_id AS messageId, mr.emoji, COUNT(*) AS count, MAX(CASE WHEN mr.reactor_type = ? AND mr.reactor_id = ? THEN 1 ELSE 0 END) AS reactedByViewer FROM message_reactions mr JOIN messages m ON m.id = mr.message_id WHERE mr.business_id = ? AND m.conversation_id = ? GROUP BY mr.message_id, mr.emoji`).bind(viewerType, viewerId, viewer.businessId, conversationId).all<{ messageId: number; emoji: string; count: number; reactedByViewer: number }>(),
    database().prepare(`SELECT mr.message_id AS messageId, mr.reader_type AS readerType, mr.reader_id AS readerId, mr.reader_name AS readerName, mr.read_at AS readAt FROM message_reads mr JOIN messages m ON m.id = mr.message_id WHERE mr.business_id = ? AND m.conversation_id = ? ORDER BY mr.read_at ASC`).bind(viewer.businessId, conversationId).all<{ messageId: number; readerType: string; readerId: number; readerName: string; readAt: number }>(),
  ]);
  const reactionsByMessage = new Map<number, Array<{ emoji: string; count: number; reactedByViewer: boolean }>>();
  for (const reaction of reactionRows.results) {
    const reactions = reactionsByMessage.get(reaction.messageId) ?? [];
    reactions.push({ emoji: reaction.emoji, count: Number(reaction.count), reactedByViewer: Boolean(reaction.reactedByViewer) });
    reactionsByMessage.set(reaction.messageId, reactions);
  }
  const readsByMessage = new Map<number, Array<{ readerType: string; readerId: number; readerName: string; readAt: number }>>();
  for (const receipt of readRows.results) {
    const receipts = readsByMessage.get(receipt.messageId) ?? [];
    receipts.push(receipt);
    readsByMessage.set(receipt.messageId, receipts);
  }
  const messages = (rows.results as Array<{ id: number }>).map((message) => ({ ...message, reactions: reactionsByMessage.get(message.id) ?? [], readBy: readsByMessage.get(message.id) ?? [] }));
  return Response.json({ enabled: true, messages }, { headers: { "cache-control": "private, no-store" } });
}

export async function POST(request: Request) {
  const { viewer, enabled } = await access();
  if (viewer.access === "pending") return Response.json({ error: "Not authorized" }, { status: 403 });
  if (!enabled) return Response.json({ error: "Messaging is disabled by the owner." }, { status: 403 });
  const body = await request.json() as { body?: string; conversationId?: string };
  const message = body.body?.trim().slice(0, 2000);
  if (!message) return Response.json({ error: "Enter a message." }, { status: 400 });
  const senderType = viewer.access === "owner" ? "owner" : "employee";
  const senderId = viewer.employeeId ?? 0;
  const createdAt = Date.now();
  const conversationId = body.conversationId?.trim().slice(0, 120) || "managers";
  const result = await database().prepare("INSERT INTO messages (business_id, conversation_id, sender_type, sender_id, sender_name, body, created_at) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id").bind(viewer.businessId, conversationId, senderType, senderId, viewer.displayName, message, createdAt).first<{ id: number }>();
  return Response.json({ id: result?.id, conversationId, senderType, senderId, senderName: viewer.displayName, body: message, createdAt }, { status: 201 });
}

export async function PATCH(request: Request) {
  const { viewer, enabled } = await access();
  if (viewer.access === "pending") return Response.json({ error: "Not authorized" }, { status: 403 });
  if (!enabled) return Response.json({ error: "Messaging is disabled by the owner." }, { status: 403 });
  const body = await request.json() as { conversationId?: string; throughMessageId?: number };
  const conversationId = body.conversationId?.trim().slice(0, 120);
  const throughMessageId = Number(body.throughMessageId);
  if (!conversationId || !Number.isInteger(throughMessageId) || throughMessageId < 1) return Response.json({ error: "Invalid read receipt." }, { status: 400 });
  const readerType = viewer.access === "employee" ? "employee" : "owner";
  const readerId = viewer.access === "employee" ? viewer.employeeId ?? 0 : 0;
  await database().prepare(`INSERT OR IGNORE INTO message_reads (message_id, business_id, reader_type, reader_id, reader_name, read_at) SELECT id, business_id, ?, ?, ?, ? FROM messages WHERE business_id = ? AND conversation_id = ? AND id <= ? AND NOT (sender_type = ? AND sender_id = ?)`).bind(readerType, readerId, viewer.displayName, Date.now(), viewer.businessId, conversationId, throughMessageId, readerType, readerId).run();
  return Response.json({ ok: true });
}

export async function PUT(request: Request) {
  const { viewer, enabled } = await access();
  if (viewer.access === "pending") return Response.json({ error: "Not authorized" }, { status: 403 });
  if (!enabled) return Response.json({ error: "Messaging is disabled by the owner." }, { status: 403 });
  const body = await request.json() as { messageId?: number; emoji?: string };
  const messageId = Number(body.messageId);
  const allowedEmojis = ["👍", "❤️", "😂", "😮", "😢", "🎉"];
  if (!Number.isInteger(messageId) || messageId < 1 || !body.emoji || !allowedEmojis.includes(body.emoji)) return Response.json({ error: "Invalid reaction." }, { status: 400 });
  const message = await database().prepare("SELECT id FROM messages WHERE id = ? AND business_id = ?").bind(messageId, viewer.businessId).first<{ id: number }>();
  if (!message) return Response.json({ error: "Message not found." }, { status: 404 });
  const reactorType = viewer.access === "employee" ? "employee" : "owner";
  const reactorId = viewer.access === "employee" ? viewer.employeeId ?? 0 : 0;
  const existing = await database().prepare("SELECT message_id FROM message_reactions WHERE message_id = ? AND reactor_type = ? AND reactor_id = ? AND emoji = ?").bind(messageId, reactorType, reactorId, body.emoji).first<{ message_id: number }>();
  if (existing) await database().prepare("DELETE FROM message_reactions WHERE message_id = ? AND reactor_type = ? AND reactor_id = ? AND emoji = ?").bind(messageId, reactorType, reactorId, body.emoji).run();
  else await database().prepare("INSERT INTO message_reactions (message_id, business_id, reactor_type, reactor_id, emoji, created_at) VALUES (?, ?, ?, ?, ?, ?)").bind(messageId, viewer.businessId, reactorType, reactorId, body.emoji, Date.now()).run();
  const total = await database().prepare("SELECT COUNT(*) AS count FROM message_reactions WHERE message_id = ? AND emoji = ?").bind(messageId, body.emoji).first<{ count: number }>();
  return Response.json({ active: !existing, count: Number(total?.count ?? 0) });
}
